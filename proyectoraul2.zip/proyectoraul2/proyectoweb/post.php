<?php
// Archivo: post.php - Vista individual de un post
require_once 'includes/db.php';
include_once 'includes/header.php';

// Verificar si se proporcionó un ID válido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: blog.php');
    exit;
}

$post_id = (int)$_GET['id'];
$conn = conectarDB();

// Obtener los detalles del post
$query = "SELECT p.id, p.titulo, p.contenido, p.imagen, p.fecha, u.nombre as autor 
          FROM posts p
          JOIN usuarios u ON p.usuario_id = u.id
          WHERE p.id = ?";
          
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Post no encontrado
    $conn->close();
    header('Location: blog.php');
    exit;
}

$post = $result->fetch_assoc();
?>

<div class="row tm-row">
    <div class="col-12">
        <hr class="tm-hr-primary">
        <article class="tm-post">
            <header>
                <h1 class="tm-pt-30 tm-color-primary tm-post-title"><?php echo htmlspecialchars($post['titulo']); ?></h1>
            </header>
            <div class="tm-post-meta">
                <span class="tm-color-primary">Por <?php echo htmlspecialchars($post['autor']); ?></span>
                <span> | </span>
                <span><?php echo date('d/m/Y', strtotime($post['fecha'])); ?></span>
            </div>
            
            <?php if (!empty($post['imagen'])): ?>
            <div class="tm-post-image">
                <img src="<?php echo UPLOADS_URL . htmlspecialchars($post['imagen']); ?>" alt="<?php echo htmlspecialchars($post['titulo']); ?>" class="img-fluid">
            </div>
            <?php endif; ?>
            
            <div class="tm-pt-30">
                <?php echo nl2br(htmlspecialchars($post['contenido'])); ?>
            </div>
        </article>
    </div>
</div>

<!-- Volver al blog -->
<div class="row tm-row">
    <div class="col-12">
        <div class="tm-pt-60">
            <a href="blog.php" class="tm-btn tm-btn-primary"><i class="fas fa-arrow-left mr-2"></i>Volver al Blog</a>
        </div>
    </div>
</div>

<?php
$conn->close();
include_once 'includes/footer.php';
?>