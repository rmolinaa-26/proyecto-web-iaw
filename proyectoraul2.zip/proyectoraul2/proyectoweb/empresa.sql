-- Adminer 4.8.1 MySQL 11.6.2-MariaDB-ubu2404 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1,	'Ropa'),
(2,	'Calzado'),
(3,	'Electrónica'),
(4,	'Computadoras'),
(5,	'Otros'),
(6,	'color');

DROP TABLE IF EXISTS `contactos`;
CREATE TABLE `contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `contactos` (`id`, `nombre`, `email`, `mensaje`, `fecha_envio`) VALUES
(1,	'Juan Perez',	'juan@example.com',	'Hola, este es un mensaje de contacto.',	'2025-03-09 15:13:13');

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `contenido` text NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha_publicacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `imagen` varchar(255) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `posts` (`id`, `titulo`, `contenido`, `usuario_id`, `fecha_publicacion`, `imagen`, `fecha`) VALUES
(1,	'Primer Post',	'Este es el contenido del primer post.',	1,	'2025-03-09 15:13:13',	NULL,	'2025-03-09 16:23:03');

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `cantidad` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) DEFAULT NULL,
  `nombre` varchar(30) NOT NULL,
  `precio` decimal(10,0) NOT NULL,
  `codigo_barras` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `productos_ibfk_3` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `productos` (`cantidad`, `id`, `categoria_id`, `nombre`, `precio`, `codigo_barras`) VALUES
(8,	129,	1,	'Camiseta Macho',	199,	'1234567890123'),
(2,	130,	1,	'Camiseta Mujer',	179,	'2234567890123'),
(43,	131,	2,	'Zapatos Deporte',	899,	'3234567890123'),
(1,	132,	2,	'Zapatos Formales',	1200,	'4234567890123'),
(8,	133,	3,	'Auriculares Inalámbricos',	899,	'5234567890123'),
(10,	134,	3,	'Cargador Portátil',	350,	'6234567890123'),
(11,	135,	3,	'Smartphone 128GB',	4999,	'7234567890123'),
(4,	136,	3,	'Smartphone 64GB',	3999,	'8234567890123'),
(5,	137,	4,	'Laptop Gaming',	14999,	'9234567890123'),
(20,	138,	4,	'Laptop Oficina',	3999,	'1034567890123'),
(15,	139,	3,	'Monitor 24 pulgadas',	250,	'1134567890123'),
(8,	140,	1,	'Teclado Mecánico',	1500,	'1234567890123'),
(0,	141,	4,	'Bicicleta de montaña',	7000,	'1334567890123'),
(0,	142,	4,	'Bicicleta urbana',	5000,	'1434567890123'),
(0,	143,	5,	'Silla de oficina',	2200,	'1534567890123'),
(0,	144,	5,	'Escritorio moderno',	3200,	'1634567890123'),
(0,	145,	3,	'Lámpara LED',	350,	'1734567890123'),
(0,	146,	3,	'Reloj digital',	550,	'1834567890123'),
(0,	147,	1,	'Chaqueta Invierno',	2500,	'1934567890123'),
(0,	148,	1,	'Abrigo Mujer',	3500,	'2034567890123'),
(0,	149,	1,	'Sombrero Playa',	600,	'2134567890123'),
(0,	150,	1,	'Gafas de Sol',	1200,	'2234567890123'),
(0,	151,	5,	'Perfume Hombre',	1500,	'2334567890123'),
(0,	152,	5,	'Perfume Mujer',	1800,	'2434567890123'),
(0,	153,	3,	'Cámara Fotográfica',	4500,	'2534567890123'),
(0,	154,	3,	'Cámara de Seguridad',	800,	'2634567890123'),
(0,	155,	1,	'Mochila Escolar',	900,	'2734567890123'),
(0,	156,	1,	'Mochila Deportiva',	1100,	'2834567890123'),
(0,	157,	5,	'Silla Gaming',	3500,	'2934567890123'),
(0,	158,	5,	'Silla Comodidad',	2200,	'3034567890123'),
(0,	159,	5,	'Cafetera Espresso',	2500,	'3134567890123'),
(0,	160,	5,	'Tetera Eléctrica',	1000,	'3234567890123');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','editor','usuario') NOT NULL DEFAULT 'usuario',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1,	'Juan Perez',	'juan@example.com',	'1234',	'admin',	'2025-03-09 15:13:13',	'2025-03-13 15:24:18');

DROP TABLE IF EXISTS `usuarios_old`;
CREATE TABLE `usuarios_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usuarios_old` (`id`, `nombre`, `email`, `password`, `fecha_registro`) VALUES
(1,	'Admin',	'admin@example.com',	'hashed_password',	'2025-03-09 15:13:13');

-- 2025-03-13 15:43:21