<?php
// Definir la constante CONTACT_EMAIL con la dirección de correo de contacto
define('CONTACT_EMAIL', 'tu-email@ejemplo.com'); // Reemplaza con tu dirección de correo electrónico

// Definir la función limpiarDatos() para sanitizar las entradas del formulario
function limpiarDatos($datos) {
    // Eliminar espacios en blanco al inicio y al final
    $datos = trim($datos);
    // Eliminar caracteres especiales como comillas simples o dobles
    $datos = stripslashes($datos);
    // Convertir caracteres especiales a entidades HTML
    $datos = htmlspecialchars($datos);
    return $datos;
}

require_once 'includes/db.php';
include_once 'includes/header.php';

// Procesar el formulario si se envía
$mensaje_resultado = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = isset($_POST['nombre']) ? limpiarDatos($_POST['nombre']) : '';
    $email = isset($_POST['email']) ? limpiarDatos($_POST['email']) : '';
    $asunto = isset($_POST['asunto']) ? limpiarDatos($_POST['asunto']) : '';
    $mensaje_texto = isset($_POST['mensaje']) ? limpiarDatos($_POST['mensaje']) : '';
    
    // Validar campos
    if (empty($nombre) || empty($email) || empty($asunto) || empty($mensaje_texto)) {
        $mensaje_resultado = '<div class="alert alert-danger">Todos los campos son obligatorios.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensaje_resultado = '<div class="alert alert-danger">Por favor, introduce un email válido.</div>';
    } else {
        // Preparar el correo
        $to = CONTACT_EMAIL;
        $subject = "Formulario de Contacto: " . $asunto;
        $message = "Nombre: $nombre\n";
        $message .= "Email: $email\n\n";
        $message .= "Mensaje:\n$mensaje_texto";
        $headers = "From: $email";
        
        // Enviar el correo
        if (mail($to, $subject, $message, $headers)) {
            $mensaje_resultado = '<div class="alert alert-success">Tu mensaje ha sido enviado correctamente. Te responderemos lo antes posible.</div>';
        } else {
            $mensaje_resultado = '<div class="alert alert-danger">Hubo un error al enviar el mensaje. Por favor, inténtalo de nuevo más tarde.</div>';
        }
    }
}
?>

<div class="row tm-row">
    <div class="col-12">
        <h2 class="tm-color-primary tm-post-title">Contactar</h2>
        <p>Rellena el siguiente formulario para ponerte en contacto con nosotros. Te responderemos lo antes posible.</p>
        
        <?php if ($mensaje_resultado): ?>
            <?php echo $mensaje_resultado; ?>
        <?php endif; ?>
        
        <form method="POST" action="contactar.php" class="tm-contact-form">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="asunto">Asunto</label>
                <input type="text" name="asunto" id="asunto" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="mensaje">Mensaje</label>
                <textarea name="mensaje" id="mensaje" rows="6" class="form-control" required></textarea>
            </div>
            
            <div class="form-group">
                <button type="submit" class="tm-btn tm-btn-primary">Enviar Mensaje</button>
            </div>
        </form>
    </div>
</div>

<div class="row tm-row">
    <div class="col-md-6">
        <div class="tm-contact-info">
            <h3 class="tm-color-primary">Información de Contacto</h3>
            <p><i class="fas fa-map-marker-alt"></i> Calle Principal, 123, Ciudad</p>
            <p><i class="fas fa-phone"></i> +34 123 456 789</p>
            <p><i class="fas fa-envelope"></i> rmolpen0806@g.educaand.es</p>
            <p><i class="fas fa-clock"></i> Lunes a Viernes: 9:00 - 18:00</p>
        </div>
    </div>
    <div class="col-md-6">
        <div class="tm-contact-social">
            <h3 class="tm-color-primary">Síguenos en Redes Sociales</h3>
            <ul class="tm-social-links">
                <li><a href="#" class="tm-social-link"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#" class="tm-social-link"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#" class="tm-social-link"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#" class="tm-social-link"><i class="fab fa-linkedin"></i></a></li>
            </ul>
        </div>
    </div>
</div>

<?php
include_once 'includes/footer.php';
?>
