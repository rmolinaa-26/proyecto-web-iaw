<?php
// Definir la URL base del sitio
define('BASE_URL', '/html/proyecto/');

// URLs para recursos estáticos
define('ASSETS_URL', BASE_URL . 'assets/');
define('UPLOADS_URL', BASE_URL . 'uploads/');
define('IMG_URL', ASSETS_URL . 'img/');

// Configuración de la base de datos (opcional, ya que está en db.php)
define('DB_HOST', '185.27.134.139');
define('DB_USER', 'if0_37335936');
define('DB_PASS', 'JVlERtQg0HypE');
define('DB_NAME', 'if0_37335936_empresa3');
define('DB_PORT', 3306);
?> 