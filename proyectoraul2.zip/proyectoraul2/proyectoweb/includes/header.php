<?php
$pagina_actual = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Sitio Web - <?php echo ucfirst($pagina_actual); ?></title>

    <!-- CSS de la plantilla -->
    <link rel="stylesheet" href="assets\css\estilos.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Fuentes -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header class="tm-header" id="tm-header">
        <div class="tm-header-wrapper">
            <div class="tm-site-header">
                <h1 class="text-center">Mi Sitio Web</h1>
            </div>
            <nav class="tm-nav" id="tm-nav">
                <ul>
                    <li class="tm-nav-item <?php echo $pagina_actual === 'index' ? 'active' : ''; ?>">
                        <a href="index.php" class="tm-nav-link">
                            <i class="fas fa-home"></i> Inicio
                        </a>
                    </li>
                    <li class="tm-nav-item <?php echo $pagina_actual === 'nosotros' ? 'active' : ''; ?>">
                        <a href="nosotros.php" class="tm-nav-link">
                            <i class="fas fa-users"></i> Nosotros
                        </a>
                    </li>
                    <li class="tm-nav-item <?php echo $pagina_actual === 'blog' ? 'active' : ''; ?>">
                        <a href="blog.php" class="tm-nav-link">
                            <i class="fas fa-blog"></i> Blog
                        </a>
                    </li>
                    <li class="tm-nav-item <?php echo $pagina_actual === 'contactar' ? 'active' : ''; ?>">
                        <a href="contactar.php" class="tm-nav-link">
                            <i class="far fa-envelope"></i> Contactar
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container-fluid">
        <main class="tm-main">