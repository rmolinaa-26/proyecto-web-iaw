</main>
    </div>
    
    <!-- Footer -->
    <footer class="tm-footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; <?php echo date('Y'); ?> Mi Sitio Web. Todos los derechos reservados.</p>
                </div>
                <div class="col-md-6 text-right">
                    <a href="admin/login.php" class="tm-footer-link">Administración</a>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="<?php echo ASSETS_URL; ?>js/jquery.min.js"></script>
    <script src="<?php echo ASSETS_URL; ?>js/templatemo-script.js"></script>
    <script src="<?php echo ASSETS_URL; ?>js/bootstrap.min.js"></script>
</body>
</html>