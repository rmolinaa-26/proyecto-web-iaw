<?php
// Incluimos el archivo db.php para hacer la conexión
include('includes/db.php');

// Intentamos realizar la conexión
$conn = conectarDB();

// Si llegamos a esta línea, significa que la conexión fue exitosa
echo "Conexión exitosa a la base de datos!";
?>
