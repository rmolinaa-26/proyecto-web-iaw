<?php
// Archivo: includes/db.php - Conexión a la base de datos en XAMPP

// Mostrar errores en modo desarrollo (desactiva en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuración de la base de datos para XAMPP
define('DEBUG', true);
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'example');  // Cambia la contraseña si es diferente
define('DB_NAME', 'empresa');
define('DB_PORT', 3308);  // Cambia el puerto si estás utilizando otro

// Configuración de correo SMTP
define('SMTP_SERVER', 'smtp.gmail.com');  // Servidor SMTP
define('SMTP_PORT', 465);  // Puerto
define('SMTP_AUTH', true);
define('SMTP_SECURE', 'ssl');
define('MAIL_USERNAME', 'Web Empresa');  // Nombre completo
define('MAIL_USER', 'rmolpen0806@g.educaand.es');  // Nombre de usuario
define('MAIL_PASS', 'dber fsqn rxmx qmgk');  // Password

// Función para conectar a la base de datos
function conectarDB() {
    try {
        // Establecer conexión con la base de datos
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        
        // Verificar si la conexión fue exitosa
        if ($conn->connect_error) {
            throw new Exception("Error de conexión: " . $conn->connect_error);
        }

        // Establecer el juego de caracteres a UTF-8
        $conn->set_charset("utf8");
        return $conn;
    } catch (Exception $e) {
        die("Error al conectar con la base de datos. Verifica las credenciales. Error: " . $e->getMessage());
    }
}

// Iniciar sesión en todas las páginas si no está iniciada
if (!defined('PHP_SESSION_NONE')) {
    define('PHP_SESSION_NONE', 1);
}
if (function_exists('session_status') && session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

