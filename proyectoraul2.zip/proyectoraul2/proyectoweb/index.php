<?php
// Archivo: index.php - Página de inicio
require_once 'includes/db.php';
include_once 'includes/header.php';
?>

<!-- Hero Section con imagen principal -->
<div class="hero-section">
    <div class="container-fluid px-0">
        <div class="row no-gutters">
            <div class="col-12">
                <div class="hero-image-container">
                    <img src="assets/img/inicio.jpg" alt="Bienvenidos a nuestra empresa" class="hero-image">
                    <div class="hero-overlay">
                        <h1 class="display-4 text-white">Bienvenidos a nuestra empresa</h1>
                        <p class="lead text-white">Innovación y calidad a su servicio</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="tm-main-content">
                <h2 class="tm-pt-30 tm-color-primary tm-post-title">Sobre Nosotros</h2>
                <p class="tm-pt-30">
                    Bienvenido a nuestra página web. Aquí encontrarás información sobre nuestra empresa, 
                    nuestros servicios y las últimas novedades en nuestro blog.
                </p>
                <p class="tm-pt-30">
                    Explora nuestra web para conocer más sobre nosotros y nuestros servicios. 
                    No dudes en contactarnos si tienes alguna pregunta o consulta.
                </p>
                
                <!-- Mostrar los últimos posts del blog -->
                <div class="row tm-row tm-mb-40">
                    <div class="col-12">
                        <h3 class="tm-color-primary tm-post-title">Últimos artículos</h3>
                    </div>
                </div>
                <div class="row tm-row tm-mb-60">
                    <?php
                    // Obtener los últimos 3 posts
                    $conn = conectarDB();
                    $query = "SELECT id, titulo, fecha, imagen FROM posts ORDER BY fecha DESC LIMIT 3";
                    $result = $conn->query($query);
                    
                    if ($result->num_rows > 0) {
                        while ($post = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4 tm-mb-sm-40">
                        <div class="tm-post-card">
                            <?php if (!empty($post['imagen'])): ?>
                            <div class="tm-post-image">
                                <img src="<?php echo UPLOADS_URL . htmlspecialchars($post['imagen']); ?>" 
                                     alt="<?php echo htmlspecialchars($post['titulo']); ?>" 
                                     class="img-fluid">
                            </div>
                            <?php endif; ?>
                            <div class="tm-post-card-body">
                                <h3 class="tm-post-card-title"><?php echo htmlspecialchars($post['titulo']); ?></h3>
                                <p class="tm-post-card-date"><?php echo date('d/m/Y', strtotime($post['fecha'])); ?></p>
                                <a href="post.php?id=<?php echo $post['id']; ?>" 
                                   class="tm-btn tm-btn-primary tm-btn-small">Leer más</a>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    } else {
                        echo "<div class='col-12'><p>No hay artículos disponibles.</p></div>";
                    }
                    $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hero-section {
    position: relative;
    margin-bottom: 3rem;
}

.hero-image-container {
    position: relative;
    width: 100%;
    height: 60vh;
    min-height: 400px;
    overflow: hidden;
}

.hero-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 2rem;
}

.hero-overlay h1 {
    font-size: 3.5rem;
    font-weight: 600;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.hero-overlay p {
    font-size: 1.5rem;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

@media (max-width: 768px) {
    .hero-image-container {
        height: 40vh;
    }
    
    .hero-overlay h1 {
        font-size: 2.5rem;
    }
    
    .hero-overlay p {
        font-size: 1.2rem;
    }
}
</style>

<?php
include_once 'includes/footer.php';
?>