<?php
// Configuración de la base de datos para XAMPP
define('DEBUG', true);
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'example');  // Cambia la contraseña si es diferente
define('DB_NAME', 'empresa');
define('DB_PORT', 3308);  // Cambia el puerto si estás utilizando otro

// Crear conexión
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    
    // Verificar conexión
    if ($conn->connect_error) {
        throw new Exception("Error de conexión: " . $conn->connect_error);
    }
    
    // Establecer charset
    $conn->set_charset("utf8");
} catch (Exception $e) {
    die("Error al conectar con la base de datos. Verifica las credenciales. Error: " . $e->getMessage());
}
?>