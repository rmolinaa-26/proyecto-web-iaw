<?php
$titulo_pagina = 'Dashboard';
include 'includes/header.php';

// Obtener los últimos 4 posts
$sql_posts = "SELECT p.id, p.titulo, p.fecha, u.nombre as autor 
              FROM posts p 
              INNER JOIN usuarios u ON p.usuario_id = u.id 
              ORDER BY p.fecha DESC 
              LIMIT 4";
$resultado_posts = $conn->query($sql_posts);
?>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Información del usuario</h5>
                <p><strong>Nombre:</strong> <?php echo $usuario['nombre']; ?></p>
                <p><strong>Email:</strong> <?php echo $usuario['email']; ?></p>
                <p><strong>Rol:</strong> <?php echo ucfirst($usuario['rol']); ?></p>
                <p><strong>Fecha de registro:</strong> <?php echo date('d/m/Y', strtotime($usuario['fecha_registro'])); ?></p>
                <p><strong>Última conexión:</strong> <?php echo date('d/m/Y H:i:s', strtotime($_SESSION['tiempo_login'])); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Estadísticas</h5>
                <?php
                // Obtener estadísticas
                $sql_stats_posts = "SELECT COUNT(*) as total FROM posts";
                $sql_stats_usuarios = "SELECT COUNT(*) as total FROM usuarios";
                
                $resultado_stats_posts = $conn->query($sql_stats_posts);
                $resultado_stats_usuarios = $conn->query($sql_stats_usuarios);
                
                $stats_posts = $resultado_stats_posts->fetch_assoc();
                $stats_usuarios = $resultado_stats_usuarios->fetch_assoc();
                ?>
                <div class="row text-center">
                    <div class="col-6">
                        <div class="display-4"><?php echo $stats_posts['total']; ?></div>
                        <p>Total Posts</p>
                    </div>
                    <div class="col-6">
                        <div class="display-4"><?php echo $stats_usuarios['total']; ?></div>
                        <p>Total Usuarios</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Últimos Posts</h5>
    </div>
    <div class="card-body">
        <?php if ($resultado_posts->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>Autor</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($post = $resultado_posts->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $post['id']; ?></td>
                                <td><?php echo $post['titulo']; ?></td>
                                <td><?php echo $post['autor']; ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($post['fecha'])); ?></td>
                                <td>
                                    <a href="posts.php?editar=<?php echo $post['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="../post.php?id=<?php echo $post['id']; ?>" target="_blank" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center">No hay posts disponibles.</p>
        <?php endif; ?>
        
        <div class="text-end mt-3">
            <a href="posts.php" class="btn btn-primary">Ver todos los posts</a>
            <a href="posts.php?nuevo" class="btn btn-success">Crear nuevo post</a>
        </div>
    </div>
</div>

<?php
include 'includes/footer.php';
?>