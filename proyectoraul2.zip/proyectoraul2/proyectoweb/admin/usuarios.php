<?php
$titulo_pagina = 'Gestión de Usuarios';
include 'includes/header.php';

// Configuración de la paginación
$usuarios_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_actual - 1) * $usuarios_por_pagina;

// Obtener total de usuarios para la paginación
$sql_total = "SELECT COUNT(*) as total FROM usuarios";
$resultado_total = $conn->query($sql_total);
$fila_total = $resultado_total->fetch_assoc();
$total_usuarios = $fila_total['total'];
$total_paginas = ceil($total_usuarios / $usuarios_por_pagina);

// Consulta para obtener los usuarios paginados
$sql = "SELECT * FROM usuarios ORDER BY id DESC LIMIT $offset, $usuarios_por_pagina";
$resultado = $conn->query($sql);

// Mensajes de operaciones
$mensaje = '';
$clase_alerta = '';

// Eliminar usuario
if (isset($_GET['eliminar']) && $_SESSION['usuario_rol'] === 'admin') {
    $id_eliminar = (int)$_GET['eliminar'];
    
    // No permitir eliminar el propio usuario
    if ($id_eliminar === $_SESSION['usuario_id']) {
        $mensaje = 'No puedes eliminar tu propio usuario.';
        $clase_alerta = 'danger';
    } else {
        $sql_eliminar = "DELETE FROM usuarios WHERE id = ?";
        $stmt_eliminar = $conn->prepare($sql_eliminar);
        $stmt_eliminar->bind_param("i", $id_eliminar);
        
        if ($stmt_eliminar->execute()) {
            $mensaje = 'Usuario eliminado correctamente.';
            $clase_alerta = 'success';
            
            // Recargar la lista
            $resultado = $conn->query($sql);
        } else {
            $mensaje = 'Error al eliminar el usuario.';
            $clase_alerta = 'danger';
        }
    }
}

// Proceso de formulario para nuevo usuario o edición
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION['usuario_rol'] === 'admin') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $nombre = $_POST['nombre'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $rol = $_POST['rol'] ?? 'editor';
    
    // Validación básica
    if (empty($nombre) || empty($email) || (empty($password) && $id === 0)) {
        $mensaje = 'Por favor, completa todos los campos obligatorios.';
        $clase_alerta = 'danger';
    } else {
        // Si es edición y no se proporciona contraseña, mantener la actual
        if ($id > 0 && empty($password)) {
            $sql_actualizar = "UPDATE usuarios SET nombre = ?, email = ?, rol = ? WHERE id = ?";
            $stmt = $conn->prepare($sql_actualizar);
            $stmt->bind_param("sssi", $nombre, $email, $rol, $id);
        } else {
            // Hash de la contraseña
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            if ($id > 0) {
                // Actualizar usuario existente con nueva contraseña
                $sql_actualizar = "UPDATE usuarios SET nombre = ?, email = ?, password = ?, rol = ? WHERE id = ?";
                $stmt = $conn->prepare($sql_actualizar);
                $stmt->bind_param("ssssi", $nombre, $email, $password_hash, $rol, $id);
            } else {
                // Insertar nuevo usuario
                $sql_insertar = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql_insertar);
                $stmt->bind_param("ssss", $nombre, $email, $password_hash, $rol);
            }
        }
        
        if ($stmt->execute()) {
            $mensaje = ($id > 0) ? 'Usuario actualizado correctamente.' : 'Usuario creado correctamente.';
            $clase_alerta = 'success';
            
            // Recargar la lista
            $resultado = $conn->query($sql);
        } else {
            $mensaje = 'Error al guardar el usuario. Puede que el email ya esté en uso.';
            $clase_alerta = 'danger';
        }
    }
}

// Cargar datos para edición
$usuario_editar = null;
if (isset($_GET['editar']) && $_SESSION['usuario_rol'] === 'admin') {
    $id_editar = (int)$_GET['editar'];
    $sql_editar = "SELECT * FROM usuarios WHERE id = ?";
    $stmt_editar = $conn->prepare($sql_editar);
    $stmt_editar->bind_param("i", $id_editar);
    $stmt_editar->execute();
    $resultado_editar = $stmt_editar->get_result();
    
    if ($resultado_editar->num_rows === 1) {
        $usuario_editar = $resultado_editar->fetch_assoc();
    }
}
?>

<?php if (!empty($mensaje)): ?>
    <div class="alert alert-<?php echo $clase_alerta; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensaje; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
<?php endif; ?>

<?php if ($_SESSION['usuario_rol'] === 'admin'): ?>
    <?php if (isset($_GET['nuevo']) || isset($_GET['editar'])): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><?php echo isset($_GET['editar']) ? 'Editar Usuario' : 'Nuevo Usuario'; ?></h5>
            </div>
            <div class="card-body">
                <form method="post" action="">
                    <?php if (isset($_GET['editar']) && $usuario_editar): ?>
                        <input type="hidden" name="id" value="<?php echo $usuario_editar['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required
                                value="<?php echo $usuario_editar['nombre'] ?? ''; ?>">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required
                                value="<?php echo $usuario_editar['email'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">
                                Contraseña <?php echo isset($_GET['editar']) ? '(Dejar en blanco para mantener actual)' : ''; ?>
                            </label>
                            <input type="password" class="form-control" id="password" name="password"
                                <?php echo isset($_GET['editar']) ? '' : 'required'; ?>>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="rol" class="form-label">Rol</label>
                            <select class="form-select" id="rol" name="rol" required>
                                <option value="editor" <?php echo (isset($usuario_editar) && $usuario_editar['rol'] === 'editor') ? 'selected' : ''; ?>>Editor</option>
                                <option value="admin" <?php echo (isset($usuario_editar) && $usuario_editar['rol'] === 'admin') ? 'selected' : ''; ?>>Administrador</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <a href="usuarios.php" class="btn btn-secondary me-2">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="d-flex justify-content-end mb-3">
            <a href="usuarios.php?nuevo" class="btn btn-success">
                <i class="fas fa-plus"></i> Nuevo Usuario
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Lista de Usuarios</h5>
    </div>
    <div class="card-body">
        <?php if ($resultado->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>Fecha Registro</th>
                            <?php if ($_SESSION['usuario_rol'] === 'admin'): ?>
                                <th>Acciones</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($usuario = $resultado->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $usuario['id']; ?></td>
                                <td><?php echo $usuario['nombre']; ?></td>
                                <td><?php echo $usuario['email']; ?></td>
                                <td><span class="badge bg-<?php echo $usuario['rol'] === 'admin' ? 'danger' : 'info'; ?>"><?php echo ucfirst($usuario['rol']); ?></span></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($usuario['fecha_registro'])); ?></td>
                                <?php if ($_SESSION['usuario_rol'] === 'admin'): ?>
                                    <td>
                                        <a href="usuarios.php?editar=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-primary me-1">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($usuario['id'] !== $_SESSION['usuario_id']): ?>
                                            <a href="usuarios.php?eliminar=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de querer eliminar este usuario?')">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Paginación -->
            <?php if ($total_paginas > 1): ?>
                <nav aria-label="Paginación">
                    <ul class="pagination justify-content-center">
                        <?php if ($pagina_actual > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina_actual - 1; ?>">Anterior</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                            <li class="page-item <?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                                <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($pagina_actual < $total_paginas): ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina_actual + 1; ?>">Siguiente</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <p class="text-center">No hay usuarios disponibles.</p>
        <?php endif; ?>
    </div>
</div>

<?php
include 'includes/footer.php';
?>