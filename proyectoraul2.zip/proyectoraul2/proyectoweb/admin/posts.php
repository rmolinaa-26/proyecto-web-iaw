<?php
$titulo_pagina = 'Gestión de Posts';
include 'includes/header.php';

// Configuración de paginación
$posts_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_actual - 1) * $posts_por_pagina;

// Obtener total y configurar paginación
$resultado_total = $conn->query("SELECT COUNT(*) as total FROM posts");
$total_posts = $resultado_total->fetch_assoc()['total'];
$total_paginas = ceil($total_posts / $posts_por_pagina);

// Consulta para posts paginados
$sql = "SELECT p.*, u.nombre as nombre_usuario FROM posts p 
        INNER JOIN usuarios u ON p.usuario_id = u.id 
        ORDER BY p.fecha DESC LIMIT $offset, $posts_por_pagina";
$resultado = $conn->query($sql);

$mensaje = '';
$clase_alerta = '';

// Eliminar post
if (isset($_GET['eliminar'])) {
    $id_eliminar = (int)$_GET['eliminar'];
    
    $stmt_info = $conn->prepare("SELECT usuario_id, imagen FROM posts WHERE id = ?");
    $stmt_info->bind_param("i", $id_eliminar);
    $stmt_info->execute();
    $post_info = $stmt_info->get_result()->fetch_assoc();
    
    // Verificar permisos y eliminar
    if ($post_info && ($_SESSION['usuario_rol'] === 'admin' || $post_info['usuario_id'] === $_SESSION['usuario_id'])) {
        // Borrar imagen si existe
        if (!empty($post_info['imagen']) && file_exists("../uploads/" . $post_info['imagen'])) {
            unlink("../uploads/" . $post_info['imagen']);
        }
        
        $stmt_eliminar = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt_eliminar->bind_param("i", $id_eliminar);
        
        if ($stmt_eliminar->execute()) {
            $mensaje = 'Post eliminado correctamente.';
            $clase_alerta = 'success';
            $resultado = $conn->query($sql);
        }
    }
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $titulo = $_POST['titulo'] ?? '';
    $contenido = $_POST['contenido'] ?? '';
    $imagen_actual = $_POST['imagen_actual'] ?? '';
    $imagen = $imagen_actual;
    
    // Procesar imagen si hay una nueva
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === 0) {
        $imagen_extension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
        if (in_array($imagen_extension, ['jpg', 'jpeg', 'png', 'gif'])) {
            $imagen = uniqid() . '.' . $imagen_extension;
            if (move_uploaded_file($_FILES['imagen']['tmp_name'], "../uploads/" . $imagen)) {
                if (!empty($imagen_actual) && file_exists("../uploads/" . $imagen_actual)) {
                    unlink("../uploads/" . $imagen_actual);
                }
            }
        }
    }
    
    // Actualizar o insertar
    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE posts SET titulo = ?, contenido = ?, imagen = ? WHERE id = ?");
        $stmt->bind_param("sssi", $titulo, $contenido, $imagen, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO posts (titulo, contenido, imagen, usuario_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $titulo, $contenido, $imagen, $_SESSION['usuario_id']);
    }
    
    if ($stmt->execute()) {
        $mensaje = ($id > 0) ? 'Post actualizado correctamente.' : 'Post creado correctamente.';
        $clase_alerta = 'success';
        $resultado = $conn->query($sql);
    }
}

// Cargar datos para edición
$post_editar = null;
if (isset($_GET['editar'])) {
    $id_editar = (int)$_GET['editar'];
    $stmt_editar = $conn->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt_editar->bind_param("i", $id_editar);
    $stmt_editar->execute();
    $post_editar = $stmt_editar->get_result()->fetch_assoc();
}
?>

<!-- HTML para mensaje de alerta -->
<?php if (!empty($mensaje)): ?>
<div class="alert alert-<?php echo $clase_alerta; ?>"><?php echo $mensaje; ?></div>
<?php endif; ?>

<!-- Formulario y tabla divididos en 2 columnas -->
<div class="row">
    <!-- Tabla de posts -->
    <div class="col-md-8">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($post = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $post['id']; ?></td>
                    <td><?php echo htmlspecialchars($post['titulo']); ?></td>
                    <td><?php echo htmlspecialchars($post['nombre_usuario']); ?></td>
                    <td><?php echo date('d/m/Y', strtotime($post['fecha'])); ?></td>
                    <td>
                        <a href="?editar=<?php echo $post['id']; ?>" class="btn btn-sm btn-info">Editar</a>
                        <a href="?eliminar=<?php echo $post['id']; ?>" class="btn btn-sm btn-danger" 
                           onclick="return confirm('¿Eliminar este post?')">Eliminar</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                    <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
    
    <!-- Formulario -->
    <div class="col-md-4">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php if ($post_editar): ?>
            <input type="hidden" name="id" value="<?php echo $post_editar['id']; ?>">
            <input type="hidden" name="imagen_actual" value="<?php echo $post_editar['imagen']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label>Título</label>
                <input type="text" class="form-control" name="titulo" required 
                       value="<?php echo $post_editar ? htmlspecialchars($post_editar['titulo']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Contenido</label>
                <textarea class="form-control" name="contenido" rows="5" required><?php 
                    echo $post_editar ? htmlspecialchars($post_editar['contenido']) : ''; 
                ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Imagen</label>
                <input type="file" class="form-control-file" name="imagen">
                <?php if ($post_editar && !empty($post_editar['imagen'])): ?>
                <div class="mt-2">
                    <img src="../uploads/<?php echo $post_editar['imagen']; ?>" alt="Imagen actual" 
                         class="img-thumbnail" style="max-width: 150px;">
                </div>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <?php echo $post_editar ? 'Actualizar' : 'Guardar'; ?>
            </button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>