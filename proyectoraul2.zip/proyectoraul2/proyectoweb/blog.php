<?php
// Archivo: blog.php - Página del Blog
require_once 'includes/db.php';
include_once 'includes/header.php';
?>

<!-- Hero Section con imagen principal -->
<div class="hero-section">
    <div class="container-fluid px-0">
        <div class="row no-gutters">
            <div class="col-12">
                <div class="hero-image-container">
                    <img src="assets/img/blog.jpg" alt="Nuestro Blog" class="hero-image">
                    <div class="hero-overlay">
                        <h1 class="display-4 text-white">Blog</h1>
                        <p class="lead text-white">Últimas noticias y artículos de interés</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="tm-main-content">
                <!-- Sección de Posts -->
                <div class="row tm-row">
                    <?php
                    $conn = conectarDB();
                    // Configuración de la paginación
                    $posts_por_pagina = 6;
                    $pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
                    $offset = ($pagina_actual - 1) * $posts_por_pagina;

                    // Obtener el total de posts
                    $sql_total = "SELECT COUNT(*) as total FROM posts";
                    $resultado_total = $conn->query($sql_total);
                    $fila_total = $resultado_total->fetch_assoc();
                    $total_posts = $fila_total['total'];
                    $total_paginas = ceil($total_posts / $posts_por_pagina);

                    // Obtener los posts para la página actual
                    $sql = "SELECT id, titulo, contenido, fecha, imagen FROM posts 
                           ORDER BY fecha DESC 
                           LIMIT ? OFFSET ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ii", $posts_por_pagina, $offset);
                    $stmt->execute();
                    $resultado = $stmt->get_result();

                    if ($resultado->num_rows > 0) {
                        while ($post = $resultado->fetch_assoc()) {
                            // Crear un extracto del contenido
                            $extracto = strip_tags($post['contenido']); // Eliminar etiquetas HTML
                            $extracto = substr($extracto, 0, 150); // Tomar los primeros 150 caracteres
                            if (strlen($post['contenido']) > 150) {
                                $extracto .= '...'; // Añadir puntos suspensivos si el contenido es más largo
                            }
                    ?>
                            <div class="col-md-6 col-lg-4 tm-mb-4">
                                <div class="card h-100">
                                    <?php if (!empty($post['imagen'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($post['imagen']); ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo htmlspecialchars($post['titulo']); ?>">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h5 class="card-title tm-color-primary"><?php echo htmlspecialchars($post['titulo']); ?></h5>
                                        <p class="card-text small text-muted">
                                            <?php echo date('d/m/Y', strtotime($post['fecha'])); ?>
                                        </p>
                                        <p class="card-text">
                                            <?php echo htmlspecialchars($extracto); ?>
                                        </p>
                                        <a href="post.php?id=<?php echo $post['id']; ?>" 
                                           class="btn btn-primary">Leer más</a>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<div class='col-12'><p class='text-center'>No hay artículos disponibles.</p></div>";
                    }
                    ?>
                </div>

                <!-- Paginación -->
                <?php if ($total_paginas > 1): ?>
                <div class="row tm-row tm-mt-100">
                    <div class="col-12">
                        <div class="tm-paging d-flex justify-content-center">
                            <?php if ($pagina_actual > 1): ?>
                                <a href="?pagina=<?php echo $pagina_actual - 1; ?>" class="tm-paging-link">
                                    <i class="fas fa-arrow-left"></i>
                                </a>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                                <a href="?pagina=<?php echo $i; ?>" 
                                   class="tm-paging-link <?php echo $i === $pagina_actual ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>

                            <?php if ($pagina_actual < $total_paginas): ?>
                                <a href="?pagina=<?php echo $pagina_actual + 1; ?>" class="tm-paging-link">
                                    <i class="fas fa-arrow-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.hero-section {
    position: relative;
    margin-bottom: 3rem;
}

.hero-image-container {
    position: relative;
    width: 100%;
    height: 60vh;
    min-height: 400px;
    overflow: hidden;
}

.hero-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 2rem;
}

.hero-overlay h1 {
    font-size: 3.5rem;
    font-weight: 600;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.hero-overlay p {
    font-size: 1.5rem;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

@media (max-width: 768px) {
    .hero-image-container {
        height: 40vh;
    }
    
    .hero-overlay h1 {
        font-size: 2.5rem;
    }
    
    .hero-overlay p {
        font-size: 1.2rem;
    }
}

.card {
    transition: transform 0.3s ease;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.card:hover {
    transform: translateY(-5px);
}

.card-img-top {
    height: 200px;
    object-fit: cover;
}

.tm-paging {
    gap: 10px;
}

.tm-paging-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border: 1px solid #007bff;
    color: #007bff;
    text-decoration: none;
    border-radius: 50%;
    transition: all 0.3s ease;
}

.tm-paging-link:hover,
.tm-paging-link.active {
    background-color: #007bff;
    color: white;
}
</style>

<?php
$conn->close();
include_once 'includes/footer.php';
?>