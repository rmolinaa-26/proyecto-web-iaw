<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image'])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $check = getimagesize($_FILES["image"]["tmp_name"]);

    if ($check !== false) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            echo "El archivo " . htmlspecialchars(basename($_FILES["image"]["name"])) . " ha sido subido.";
        } else {
            echo "Hubo un error al subir tu archivo.";
        }
    } else {
        echo "El archivo no es una imagen válida.";
    }
}
?>

<!-- Formulario de subida -->
<form action="upload.php" method="post" enctype="multipart/form-data">
    Selecciona una imagen:
    <input type="file" name="image" id="image">
    <input type="submit" value="Subir Imagen" name="submit">
</form>
