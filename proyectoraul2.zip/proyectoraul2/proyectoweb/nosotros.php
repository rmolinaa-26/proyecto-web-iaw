<?php
// Archivo: nosotros.php - Página de Nosotros/Quiénes somos
require_once 'includes/db.php';
include_once 'includes/header.php';
?>

<!-- Hero Section con imagen principal -->
<div class="hero-section">
    <div class="container-fluid px-0">
        <div class="row no-gutters">
            <div class="col-12">
                <div class="hero-image-container">
                    <img src="assets/img/nosotros.jpg" alt="Sobre Nosotros" class="hero-image">
                    <div class="hero-overlay">
                        <h1 class="display-4 text-white">Sobre Nosotros</h1>
                        <p class="lead text-white">Conoce nuestra historia y valores</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="tm-main-content">
                <p class="tm-pt-30">
                    Somos una empresa dedicada a ofrecer soluciones innovadoras para nuestros clientes. 
                    Fundada en 2010, hemos crecido hasta convertirnos en líderes del sector.
                </p>
                
                <div class="row tm-row mt-4">
                    <div class="col-md-6">
                        <div class="tm-about-2-col">
                            <h3 class="tm-color-primary">Nuestra Misión</h3>
                            <p>
                                Nuestra misión es proporcionar servicios de alta calidad que satisfagan 
                                las necesidades de nuestros clientes y superen sus expectativas.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="tm-about-2-col">
                            <h3 class="tm-color-primary">Nuestra Visión</h3>
                            <p>
                                Aspiramos a ser reconocidos como la empresa líder en nuestro sector, 
                                conocida por la excelencia, la innovación y el compromiso con nuestros clientes.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Sección de Equipo -->
                <div class="tm-pt-30">
                    <h3 class="tm-color-primary">Nuestro Equipo</h3>
                    <p>
                        Contamos con un equipo de profesionales altamente cualificados y comprometidos con la 
                        excelencia. Cada miembro de nuestro equipo aporta conocimientos y experiencia únicos 
                        que nos permiten ofrecer soluciones a medida para cada cliente.
                    </p>
                </div>
                
                <!-- Sección de Historia -->
                <div class="tm-pt-30">
                    <h3 class="tm-color-primary">Nuestra Historia</h3>
                    <p>
                        Nuestra empresa comenzó como un pequeño proyecto con grandes ambiciones. A lo largo de los años, 
                        hemos enfrentado desafíos y celebrado éxitos, siempre manteniendo nuestro compromiso con la calidad 
                        y la satisfacción del cliente.
                    </p>
                    <p>
                        Desde nuestros humildes comienzos, hemos expandido nuestras operaciones y diversificado nuestros 
                        servicios para satisfacer las necesidades cambiantes del mercado. Hoy, nos enorgullece ser una 
                        empresa reconocida y respetada en nuestra industria.
                    </p>
                </div>
                
                <!-- Sección de Valores -->
                <div class="tm-pt-30">
                    <h3 class="tm-color-primary">Nuestros Valores</h3>
                    <ul class="tm-list">
                        <li><strong>Integridad:</strong> Actuamos con honestidad y transparencia en todas nuestras operaciones.</li>
                        <li><strong>Excelencia:</strong> Nos esforzamos por superar las expectativas en todo lo que hacemos.</li>
                        <li><strong>Innovación:</strong> Buscamos constantemente nuevas y mejores formas de hacer las cosas.</li>
                        <li><strong>Compromiso:</strong> Nos dedicamos a satisfacer las necesidades de nuestros clientes.</li>
                        <li><strong>Trabajo en equipo:</strong> Colaboramos para lograr objetivos comunes.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hero-section {
    position: relative;
    margin-bottom: 3rem;
}

.hero-image-container {
    position: relative;
    width: 100%;
    height: 60vh;
    min-height: 400px;
    overflow: hidden;
}

.hero-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 2rem;
}

.hero-overlay h1 {
    font-size: 3.5rem;
    font-weight: 600;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.hero-overlay p {
    font-size: 1.5rem;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

@media (max-width: 768px) {
    .hero-image-container {
        height: 40vh;
    }
    
    .hero-overlay h1 {
        font-size: 2.5rem;
    }
    
    .hero-overlay p {
        font-size: 1.2rem;
    }
}

.tm-list {
    list-style: none;
    padding-left: 0;
}

.tm-list li {
    margin-bottom: 1rem;
    padding-left: 1.5rem;
    position: relative;
}

.tm-list li:before {
    content: "•";
    color: var(--primary);
    font-weight: bold;
    position: absolute;
    left: 0;
}
</style>

<?php
include_once 'includes/footer.php';
?>